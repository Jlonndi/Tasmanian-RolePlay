fx_version 'adamant'
games { 'common' }

author { 'whocares' }
description { 'Another FiveM loading screen' }
version '0.2.0'

loadscreen 'loadscreen.html'

files {
    'loadscreen.html',
    'css/hydroui.css',
    'img/logo.png',
    'js/script.js',
    'weather.js',
    'css.css',
    'mini-jquery-bgswitcher.js',
    'mini-jquery-bgswitcher.min.js',
}